/* ზოგი დავალებები ვერ გავარკვიე*/

/*let family = ["maia",12,"sandro",24,"kakha",36,"lizi",48]
console.log(family);
*/

/*let arr = ['a', 'b', 'c', 'd'];
arr.splice(1,1, 'x');
console.log(arr);
*/



/*let arr = [];
arr.push('a', 'b', 'c');
document.write(arr);
*/

/*let arr = [1, 2, 3, 4, 5];
let key1 = 1;
let key2 = 2;
console.log(key1 + key2,)
*/

/*let arr = ['a', 'b', 'c', 'd', 'e'];
delete arr['1'];
delete arr['3'];
console.log(arr);
*/

/*let names = ['ხვიჩა', 'გოგა' ,'მაკა', 'ანა', 'ინა'];
names.sort();
document.write(names);
*/

/*let names = ['ხვიჩა', 'გოგა' ,'მაკა', 'ანა', 'ინა'];
names.sort();
names.reverse();
document.write(names);
*/
/*
let arr = [11, 22, 33, 44, 55];
console.log(arr[4]);
*/

/*let arr = [10, 11, 12, 13, 14];
console.log(arr.length);
*/

/*let arr = [10, 11, 12, 13, 14];
console.log(arr.length);
*/

/*let a = ['1', '2', '3'];
a = [];
let b = a;
console.log(b); // [1,2,3]
*/

/*var income = ['100', '200', '300']
function priceSum(){
    var income = 100 + 200 + 300

}
console.log(income)
*/

/*let toys = ['ოვერბორდი', 'პაზლი', 'Lego'];

toys.push('ბურთი');
console.log(toys)
*/


/*let ar = ['red','green','blue','purple','orange']
*/


/*
let toys = ['ოვერბორდი', 'პაზლი', 'Lego'];
let toy = 'Yo-yo';
function addToy(){

}
console.log()
*/

/*let toys = ['ოვერბორდი', 'პაზლი', 'Lego', 'Yo-yo'];
function getLastToy (){
}
*/