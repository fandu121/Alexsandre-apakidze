
let answer = ("red");

let userAnswer = prompt ("What Color Is Mars?");

/*let result = userAnswer.toLowerCase();*/

if (answer == result){
    document.write("correct answer");
}
else  {
    document.write("Incorrect answer");
}
